import { useEffect, useState, type SVGProps } from 'react';

type Language = 'es' | 'en' | 'fr';

type Translation = {
  title: string;
  languageLabel: string;
  welcome: string;
  introduction: string;
  conviction: string;
  introductionEnd: string;
  identity: string;
  greeting: string;
  enter: string;
  linksLabel: string;
  testing: string;
  community: string;
  catalog: string;
  rights: string;
  privacy: string;
  terms: string;
  newTab: string;
};

const translations: Record<Language, Translation> = {
  es: {
    title: 'Nexum Labs | Bienvenido',
    languageLabel: 'Seleccionar idioma',
    welcome: 'La ciencia nos conecta',
    introduction:
      'Nexum Labs es una marca de nueva generaci\u00f3n, nacida de una convicci\u00f3n sencilla: ',
    conviction: 'la ciencia, la est\u00e9tica y la exigencia pertenecen al mismo universo.',
    introductionEnd: ' Un universo premium, preciso e inmediatamente reconocible.',
    identity:
      'M\u00e1s que una tienda, construimos una identidad: sus c\u00f3digos, su rigor y una comunidad comprometida que comparte una misma visi\u00f3n.',
    greeting: 'Bienvenido/a!',
    enter: 'Entrar en Nexum Labs',
    linksLabel: 'Antes de entrar',
    testing: 'An\u00e1lisis por lote',
    community: 'Nuestra comunidad',
    catalog: 'Cat\u00e1logo',
    rights: 'Todos los derechos reservados.',
    privacy: 'Privacidad',
    terms: 'T\u00e9rminos',
    newTab: 'se abre en una nueva pesta\u00f1a',
  },
  en: {
    title: 'Nexum Labs | Welcome',
    languageLabel: 'Select language',
    welcome: 'Connected by science',
    introduction:
      'Nexum Labs is a next-generation brand, born of a simple conviction: ',
    conviction: 'science, aesthetics and exacting standards belong to the same universe.',
    introductionEnd: ' A premium universe, precise and instantly recognisable.',
    identity:
      'More than a shop, we are building an identity: its codes, its rigour and an engaged community that shares one vision.',
    greeting: 'Welcome!',
    enter: 'Enter Nexum Labs',
    linksLabel: 'Before you enter',
    testing: 'Batch testing',
    community: 'Our community',
    catalog: 'Catalogue',
    rights: 'All rights reserved.',
    privacy: 'Privacy',
    terms: 'Terms',
    newTab: 'opens in a new tab',
  },
  fr: {
    title: 'Nexum Labs | Bienvenue',
    languageLabel: 'Choisir la langue',
    welcome: 'La science nous relie',
    introduction:
      'Nexum Labs est une marque de nouvelle g\u00e9n\u00e9ration, n\u00e9e d\u2019une conviction simple : ',
    conviction: 'la science, l\u2019esth\u00e9tique et l\u2019exigence appartiennent au m\u00eame univers.',
    introductionEnd: ' Un univers premium, pr\u00e9cis et imm\u00e9diatement reconnaissable.',
    identity:
      'Plus qu\u2019une boutique, nous construisons une identit\u00e9 : ses codes, sa rigueur et une communaut\u00e9 engag\u00e9e qui partage une m\u00eame vision.',
    greeting: 'Bienvenue !',
    enter: 'Entrer chez Nexum Labs',
    linksLabel: 'Avant d\u2019entrer',
    testing: 'Analyses par lot',
    community: 'Notre communaut\u00e9',
    catalog: 'Catalogue',
    rights: 'Tous droits r\u00e9serv\u00e9s.',
    privacy: 'Confidentialit\u00e9',
    terms: 'Conditions',
    newTab: 's\u2019ouvre dans un nouvel onglet',
  },
};

const languageKey = 'nexum-access-language';
const logoSources = [
  'https://nexumlabs.eu/logo.png',
  'https://nexumlabs.eu/_next/image?url=%2Flogo.png&w=1200&q=90',
];

function initialLanguage(): Language {
  try {
    const saved = localStorage.getItem(languageKey);
    if (saved === 'es' || saved === 'en' || saved === 'fr') return saved;
  } catch {
    // The page also works when browser storage is unavailable.
  }
  return 'es';
}

function ArrowRight(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}>
      <path d="M4 12h15m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ArrowUpRight(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 16 16" fill="none" aria-hidden="true" {...props}>
      <path d="M4 12 12 4M4 4h8v8" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Globe(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" {...props}>
      <circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.3" />
      <ellipse cx="12" cy="12" rx="3.5" ry="8.5" stroke="currentColor" strokeWidth="1.3" />
      <path d="M3.5 12h17" stroke="currentColor" strokeWidth="1.3" />
    </svg>
  );
}

export default function App() {
  const [language, setLanguage] = useState<Language>(initialLanguage);
  const [logoAttempt, setLogoAttempt] = useState(0);
  const copy = translations[language];
  const site = `https://nexumlabs.eu${language === 'es' ? '' : `/${language}`}`;

  useEffect(() => {
    document.documentElement.lang = language;
    document.title = copy.title;
    document.querySelector('meta[name="description"]')?.setAttribute(
      'content',
      `${copy.introduction}${copy.conviction}${copy.introductionEnd}`,
    );
    try {
      localStorage.setItem(languageKey, language);
    } catch {
      // Remembering a language is optional, not a requirement for navigation.
    }
  }, [language, copy]);

  const gatewayLinks = [
    { label: copy.testing, href: 'https://nexumlabs.eu/coa' },
    { label: copy.community, href: 'https://t.me/nexumlabsgroup' },
    { label: copy.catalog, href: 'https://nexumlabs.eu/products' },
  ];

  return (
    <div className="landing relative isolate flex min-h-svh flex-col overflow-hidden">
      <div className="page-atmosphere pointer-events-none absolute inset-0 -z-10" aria-hidden="true">
        <div className="orbit orbit--upper">
          <span className="orbit-node orbit-node--one" />
          <span className="orbit-node orbit-node--two" />
        </div>
        <div className="orbit orbit--lower">
          <span className="orbit-node orbit-node--one" />
          <span className="orbit-node orbit-node--two" />
        </div>
      </div>

      <header className="site-header flex items-center justify-end">
        <div className="language-control relative inline-flex items-center">
          <Globe className="language-globe pointer-events-none" />
          <label className="sr-only" htmlFor="language">{copy.languageLabel}</label>
          <select
            id="language"
            value={language}
            onChange={(event) => setLanguage(event.target.value as Language)}
          >
            <option value="es">{'Espa\u00f1ol'}</option>
            <option value="en">English</option>
            <option value="fr">{'Fran\u00e7ais'}</option>
          </select>
          <svg className="language-chevron pointer-events-none" viewBox="0 0 12 12" fill="none" aria-hidden="true">
            <path d="m3 4.5 3 3 3-3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </header>

      <main className="gateway-main flex flex-1 items-center justify-center">
        <section className="gateway-content text-center" aria-labelledby="nexum-title">
          <p className="welcome-line entrance entrance--one" key={`welcome-${language}`}>
            <span className="welcome-dash" aria-hidden="true" />
            {copy.welcome}
            <span className="welcome-dash" aria-hidden="true" />
          </p>

          <h1 id="nexum-title" className="brand-logo entrance entrance--two">
            <span className="sr-only">Nexum Labs</span>
            {logoAttempt < logoSources.length ? (
              <img
                className="official-logo"
                src={logoSources[logoAttempt]}
                alt=""
                width="1200"
                height="264"
                decoding="async"
                fetchPriority="high"
                onError={() => setLogoAttempt((attempt) => attempt + 1)}
              />
            ) : (
              <span className="logo-fallback" aria-hidden="true">NEXUM<span>LABS</span></span>
            )}
          </h1>

          <div className="brand-divider entrance entrance--three" aria-hidden="true" />

          <div className="brand-story entrance entrance--three" key={`story-${language}`}>
            <p>
              {copy.introduction}
              <strong>{copy.conviction}</strong>
              {copy.introductionEnd}
            </p>
            <p>{copy.identity}</p>
            <p className="greeting">{copy.greeting}</p>
          </div>

          <div className="entry-action entrance entrance--four">
            <a
              className="enter-button inline-flex items-center justify-between"
              href="https://nexumlabs.eu"
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`${copy.enter}, ${copy.newTab}`}
            >
              <span>{copy.enter}</span>
              <ArrowRight className="enter-arrow" />
            </a>
          </div>

          <nav className="trust-nav entrance entrance--five" aria-label={copy.linksLabel}>
            {gatewayLinks.map((link) => (
              <a
                key={link.href}
                className="trust-link inline-flex items-center"
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`${link.label}, ${copy.newTab}`}
              >
                <span>{link.label}</span>
                <ArrowUpRight />
              </a>
            ))}
          </nav>
        </section>
      </main>

      <footer className="site-footer entrance entrance--six">
        <p className="copyright">
          <span>{`\u00a9 ${new Date().getFullYear()} Nexum Labs`}</span>
          <span className="copyright-rights">{copy.rights}</span>
        </p>
        <nav className="legal-links flex items-center" aria-label={language === 'es' ? 'Informaci\u00f3n legal' : language === 'fr' ? 'Informations l\u00e9gales' : 'Legal information'}>
          <a href={`${site}/privacy`} target="_blank" rel="noopener noreferrer" aria-label={`${copy.privacy}, ${copy.newTab}`}>{copy.privacy}</a>
          <span className="legal-dot" aria-hidden="true" />
          <a href={`${site}/terms`} target="_blank" rel="noopener noreferrer" aria-label={`${copy.terms}, ${copy.newTab}`}>{copy.terms}</a>
        </nav>
      </footer>
    </div>
  );
}
